<div class="container mx-auto px-6 pt-4 xl:px-4">
  <slot />
</div>
