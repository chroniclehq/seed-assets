<script lang="ts">
  import { redirect } from '@sveltejs/kit';

  redirect(301, '/');
</script>
